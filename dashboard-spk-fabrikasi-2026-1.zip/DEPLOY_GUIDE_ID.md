# LANGKAH DEPLOY PALING SINGKAT

## A. GitHub
1. New repository
2. Nama: dashboard-spk-fabrikasi-2026
3. Upload isi ZIP ini

## B. Google Cloud
1. Enable Google Sheets API
2. Create Service Account
3. Create JSON key
4. Share Google Sheet ke email Service Account sebagai Viewer

## C. OpenAI
1. Buat OpenAI API key
2. Jangan masukkan API key ke GitHub

## D. Streamlit
1. Create app
2. Pilih repository GitHub tadi
3. Branch: main
4. Main file: streamlit_app.py
5. Settings → Secrets
6. Paste isi secrets.toml.example setelah mengganti placeholder
7. Deploy

## Menu aplikasi
- Dashboard Utama
- Proyek & Vendor
- Area & Bulan
- SPK Prioritas
- Profil Material
- AI Analyst
